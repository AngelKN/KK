package com.cdp.libreriamiguel;

import static com.cdp.libreriamiguel.DB.DBHelper.TABLE_REGISTROS;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cdp.libreriamiguel.DB.DBHelper;
import com.cdp.libreriamiguel.DB.DBLibreria;
import com.cdp.libreriamiguel.atributos.Usuario;

public class MainActivity extends AppCompatActivity {

    EditText txtUsuario, txtContraseña;
    Button btnCrear, btnReistro, btnLogin;
    TextView txtRegistro;
    Usuario use, usuario;
    boolean validar;
    SharedPreference sp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnCrear=findViewById(R.id.btnLogin);
        btnLogin=findViewById(R.id.btnLogin);
        txtRegistro=findViewById(R.id.txtMensajeRegistra3);
        txtUsuario=findViewById(R.id.viewUsuario);
        txtContraseña=findViewById(R.id.viewContraseña);

        use = new Usuario();
        sp = new SharedPreference(MainActivity.this);
        validar = false;


        txtRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                next();
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBLibreria libreria = new DBLibreria(MainActivity.this);
                SQLiteDatabase db = libreria.getWritableDatabase();

                use.setCorreo(txtUsuario.getText().toString());
                use.setContraseña(txtContraseña.getText().toString());

                usuario = new Usuario();
                usuario = libreria.validar(use);

                if(usuario != null)
                {
                    Toast.makeText(MainActivity.this, "Bienvenido", Toast.LENGTH_LONG).show();
                    sp.setSharedPreferences(usuario);
                    login();
                }else
                {
                    Toast.makeText(MainActivity.this, "Error en usuario o contraseña", Toast.LENGTH_LONG).show();
                }
            }
        });
        /*btnCrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelper helper = new DBHelper(MainActivity.this);

                SQLiteDatabase db = helper.getWritableDatabase();
                ContentValues values = new ContentValues();


                if(db != null)
                {
                    Toast.makeText(MainActivity.this, "BASE DE DATOS CREADA", Toast.LENGTH_LONG).show();
                }else
                {
                    Toast.makeText(MainActivity.this, "ERROR AL CREAR BASE DE DATOS", Toast.LENGTH_LONG).show();
                }

            }
        });*/
    }

    private void login()
    {
        Intent intent = new Intent(this, PagPrincipal.class);
        startActivity(intent);
    }

    private void next()
    {
        Intent intent = new Intent(this, RegistrarActivity.class);
        startActivity(intent);
    }
}