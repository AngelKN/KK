package com.cdp.libreriamiguel.adaptadores;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cdp.libreriamiguel.ActualizarLibroActivity;
import com.cdp.libreriamiguel.ListaUsuariosActivity;
import com.cdp.libreriamiguel.MiPrestarLibroActivity;
import com.cdp.libreriamiguel.R;
import com.cdp.libreriamiguel.atributos.Libro;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ListaPrestar extends RecyclerView.Adapter<ListaPrestar.LibroViewHolder>{

    ArrayList<Libro> listaLibro;

    public ListaPrestar(ArrayList<Libro> listaLibro){
        this.listaLibro = listaLibro;
    }

    @NonNull
    @Override
    public ListaPrestar.LibroViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista_item_libros, null, false);
        return new ListaPrestar.LibroViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListaPrestar.LibroViewHolder holder, int position) {
        Picasso.get().load(listaLibro.get(position).getImagenLi()).error(R.mipmap.ic_launcher_round).into(holder.viewImg);
        holder.viewNombre.setText(listaLibro.get(position).getNombreLi());
        holder.viewAutor.setText(listaLibro.get(position).getAutorLi());
    }

    @Override
    public int getItemCount() {
        return listaLibro.size();
    }

    public class LibroViewHolder extends RecyclerView.ViewHolder {
        TextView viewNombre, viewAutor;
        ImageView viewImg;

        public LibroViewHolder(@NonNull View itemView) {
            super(itemView);
            viewImg=itemView.findViewById(R.id.viewImg);
            viewNombre=itemView.findViewById(R.id.viewNombreLibro);
            viewAutor=itemView.findViewById(R.id.viewAutorLibro);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Context context = view.getContext();

                    Intent intent = new Intent(context, ListaUsuariosActivity.class);
                    intent.putExtra("ID", listaLibro.get(getAdapterPosition()).getId());

                    context.startActivity(intent);
                }
            });
        }
    }
}
