package com.cdp.libreriamiguel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdp.libreriamiguel.DB.DBLibreria;
import com.cdp.libreriamiguel.adaptadores.ListaDisponibles;
import com.cdp.libreriamiguel.adaptadores.ListaPrestar;
import com.cdp.libreriamiguel.adaptadores.MisPrestados;
import com.cdp.libreriamiguel.adaptadores.PrincipalAdapter;
import com.cdp.libreriamiguel.atributos.Libro;

import java.util.ArrayList;

public class LibrosDispoPrestaActivity extends AppCompatActivity {

    SharedPreference sp;
    TextView txtRol, txtNombreA, txtTitulo;
    ImageView img;
    ImageButton btnReturn;
    RecyclerView listaLibro;
    ArrayList<Libro> listaArrayLibro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_libros_dispo_presta);
        txtTitulo=findViewById(R.id.txtTituloAdmin);
        img=findViewById(R.id.viewImg);

        btnReturn=findViewById(R.id.btnMenuAdmin);
        txtRol=findViewById(R.id.txtRolActualizar);
        txtNombreA=findViewById(R.id.txtNombreActualizar);
        sp = new SharedPreference(this);
        txtRol.setText(sp.getSharedPreferences("rol"));
        txtNombreA.setText(sp.getSharedPreferences("nombre"));

        listaLibro=findViewById(R.id.listaLibros);
        listaLibro.setLayoutManager(new LinearLayoutManager(this));

        if(txtRol.getText().toString().equals("Usuario")){

            txtTitulo.setText("Libros Disponibles");
            //img.setImageResource(R.drawable.ic_eye); //SOLUCIONAR

            DBLibreria libreria = new DBLibreria(LibrosDispoPrestaActivity.this);
            listaArrayLibro = new ArrayList<>();

            ListaDisponibles adapter = new ListaDisponibles(libreria.mostrarDisponibles());
            listaLibro.setAdapter(adapter);

        }else {

            txtTitulo.setText("Libros Prestados");
            //img.setImageResource(R.drawable.admin); //SOLUCIONAR

            DBLibreria libreria = new DBLibreria(LibrosDispoPrestaActivity.this);
            listaArrayLibro = new ArrayList<>();

            ListaPrestar adapter = new ListaPrestar(libreria.mostrarPrestados());
            listaLibro.setAdapter(adapter);

        }

        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                volver();
            }
        });
    }

    private void volver()
    {
        Intent intent = new Intent(this, PagPrincipal.class);
        startActivity(intent);
    }
}