package com.cdp.libreriamiguel;

import android.content.Context;
import android.content.SharedPreferences;

import com.cdp.libreriamiguel.atributos.Usuario;

public class SharedPreference {
    Context context;

    SharedPreferences sh;

    SharedPreferences.Editor editor;

    public SharedPreference(Context context) {
        this.context = context;
        sh = context.getSharedPreferences("base_sh", Context.MODE_PRIVATE);
        editor = sh.edit();
    }

    public void setSharedPreferences(Usuario use) {
        editor.putString("rol", use.getRol().toString());
        editor.putString("nombre", use.getNombre().toString());
        editor.putString("correo", use.getCorreo().toString());
        editor.putString("telefono", use.getTelefono().toString());
        editor.putString("direccion", use.getDireccion().toString());
        editor.apply();
    }

    public void setSharedPreferences1(String tipo){
        editor.putString("tipo", tipo);
        editor.apply();
    }

    public String getSharedPreferences(String nam)
    {
        return sh.getString(nam,"dato no encontrado");
    }
}
