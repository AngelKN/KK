package com.cdp.libreriamiguel.atributos;

public class Libro {

    private int id;
    private String nombreLi;
    private String autorLi;
    private int cantidadLi;
    private String urlLi;
    private String imagenLi;
    private String descripcionLi;
    private String correo;
    private String fechaHora;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreLi() {
        return nombreLi;
    }

    public void setNombreLi(String nombreLi) {
        this.nombreLi = nombreLi;
    }

    public String getAutorLi() {
        return autorLi;
    }

    public void setAutorLi(String autorLi) {
        this.autorLi = autorLi;
    }

    public int getCantidadLi() {
        return cantidadLi;
    }

    public void setCantidadLi(int cantidadLi) {
        this.cantidadLi = cantidadLi;
    }

    public String getUrlLi() {
        return urlLi;
    }

    public void setUrlLi(String urlLi) {
        this.urlLi = urlLi;
    }

    public String getImagenLi() {
        return imagenLi;
    }

    public void setImagenLi(String imagenLi) {
        this.imagenLi = imagenLi;
    }

    public String getDescripcionLi() {
        return descripcionLi;
    }

    public void setDescripcionLi(String descripcionLi) {
        this.descripcionLi = descripcionLi;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechahora) {
        this.fechaHora = fechahora;
    }
}
