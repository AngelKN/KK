package com.cdp.libreriamiguel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdp.libreriamiguel.DB.DBLibreria;
import com.cdp.libreriamiguel.adaptadores.ListaPrestar;
import com.cdp.libreriamiguel.adaptadores.ListaUsuariosAdapter;
import com.cdp.libreriamiguel.atributos.Libro;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ListaUsuariosActivity extends AppCompatActivity {

    SharedPreference sp;
    TextView txtRol, txtNombreA, txtTitulo, txtNombreLib, txtAutorLib, txtDescripLib;
    ImageView img;
    ImageButton btnReturn;
    RecyclerView listaLibro;
    ArrayList<Libro> listaArrayLibro;
    int id=0;
    Libro libro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_usuarios);
        txtNombreLib=findViewById(R.id.txtNombreLib);
        txtAutorLib=findViewById(R.id.txtAutorLib);
        txtDescripLib=findViewById(R.id.txtDescripLib);
        txtTitulo=findViewById(R.id.txtTituloAdmin);
        img=findViewById(R.id.imgLibro);

        btnReturn=findViewById(R.id.btnMenuAdmin);
        txtRol=findViewById(R.id.txtRolActualizar);
        txtNombreA=findViewById(R.id.txtNombreActualizar);
        sp = new SharedPreference(this);
        txtRol.setText(sp.getSharedPreferences("rol"));
        txtNombreA.setText(sp.getSharedPreferences("nombre"));

        listaLibro=findViewById(R.id.listaUser);
        listaLibro.setLayoutManager(new LinearLayoutManager(this));

        if(savedInstanceState == null){
            Bundle extras = getIntent().getExtras();
            if(extras == null){
                id = Integer.parseInt(null);
            }else{
                id = extras.getInt("ID");
            }
        }else
        {
            id = (int) savedInstanceState.getSerializable("ID");
        }

        DBLibreria libreria = new DBLibreria(ListaUsuariosActivity.this);

        libro = libreria.verLibroPrestados(id);
        txtTitulo.setText("Mi Libro");

        if(libro != null) {
            Picasso.get().load(libro.getImagenLi()).error(R.mipmap.ic_launcher_round).into(img);
            txtNombreLib.setText(libro.getNombreLi());
            txtAutorLib.setText(libro.getAutorLi());
            txtDescripLib.setText(libro.getDescripcionLi());
        }
        listaArrayLibro = new ArrayList<>();

        ListaUsuariosAdapter adapter = new ListaUsuariosAdapter(libreria.mostrarPrestadosLib(libro.getNombreLi()));
        listaLibro.setAdapter(adapter);

        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                volver();
            }
        });

    }

    private void volver()
    {
        Intent intent = new Intent(this, LibrosDispoPrestaActivity.class);
        startActivity(intent);
    }
}