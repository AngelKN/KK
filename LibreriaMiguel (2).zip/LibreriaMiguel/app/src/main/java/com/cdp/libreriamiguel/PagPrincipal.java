package com.cdp.libreriamiguel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cdp.libreriamiguel.DB.DBLibreria;
import com.cdp.libreriamiguel.adaptadores.ListaPrestar;
import com.cdp.libreriamiguel.adaptadores.MisPrestados;
import com.cdp.libreriamiguel.adaptadores.PrincipalAdapter;
import com.cdp.libreriamiguel.atributos.Libro;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PagPrincipal extends AppCompatActivity {

    LinearLayout menu;
    RecyclerView listaLibro;
    ArrayList<Libro> listaArrayLibro;
    SharedPreference sp;
    TextView txtRol, txtNombre, txtTitulo;
    ImageButton btnlista;
    Button btnPrestados, btnPrestar, btnAgregar, btnSalir;
    ImageView img;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pag_principal);
        menu=findViewById(R.id.menu);
        btnPrestados=findViewById(R.id.btnPrestados);
        btnPrestar=findViewById(R.id.btnPrestar);
        btnAgregar=findViewById(R.id.btnAgregar);
        btnSalir=findViewById(R.id.btnSalir);
        txtTitulo=findViewById(R.id.txtTituloAdmin);
        img=findViewById(R.id.imgAdmin);
        btnlista=findViewById(R.id.btnMenuAdmin);

        sp = new SharedPreference(this);
        txtRol=findViewById(R.id.txtRolActualizar);
        txtNombre=findViewById(R.id.txtNombreActualizar);
        txtRol.setText(sp.getSharedPreferences("rol"));
        txtNombre.setText(sp.getSharedPreferences("nombre"));

        btnlista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                menu.setVisibility(LinearLayout.VISIBLE);
            }
        });
        btnPrestados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prestados();
            }
        });
        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.setSharedPreferences1("AGREGAR");
                agregar();
            }
        });
        btnSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salir();
            }
        });

        if(txtRol.getText().toString().equals("Usuario")){

            btnPrestar.setVisibility(View.VISIBLE);
            txtTitulo.setText("Mis Libros Prestados");
            img.setImageResource(R.drawable.suser);

            listaLibro=findViewById(R.id.listaLibros);
            listaLibro.setLayoutManager(new LinearLayoutManager(this));
            DBLibreria libreria = new DBLibreria(PagPrincipal.this);
            listaArrayLibro = new ArrayList<>();

            MisPrestados adapter = new MisPrestados(libreria.mostrarPrestadosUse(sp.getSharedPreferences("correo")));
            listaLibro.setAdapter(adapter);

        }else{

            btnPrestar.setVisibility(View.INVISIBLE);
            txtTitulo.setText("Libros Disponibles");
            btnPrestados.setVisibility(View.VISIBLE);
            btnAgregar.setVisibility(View.VISIBLE);
            img.setImageResource(R.drawable.admin);

            listaLibro=findViewById(R.id.listaLibros);
            listaLibro.setLayoutManager(new LinearLayoutManager(this));
            DBLibreria libreria = new DBLibreria(PagPrincipal.this);
            listaArrayLibro = new ArrayList<>();

            PrincipalAdapter adapter = new PrincipalAdapter(libreria.mostrarDisponibles());
            listaLibro.setAdapter(adapter);

        }

        btnPrestar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prestados();
            }
        });
    }

    private void agregar()
    {
        Intent intent = new Intent(this, AgregarActivity.class);
        startActivity(intent);
    }

    private void prestados()
    {
        Intent intent = new Intent(this, LibrosDispoPrestaActivity.class);
        startActivity(intent);
    }

    private void salir()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}