package com.cdp.libreriamiguel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cdp.libreriamiguel.DB.DBLibreria;
import com.cdp.libreriamiguel.atributos.Libro;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Date;

public class MiPrestarLibroActivity extends AppCompatActivity {

    SharedPreference sp;
    Button btndevolver, btnVer;
    TextView txtRol, txtNombreA, txtTitulo, txtNombreLib, txtAutorLib, txtDescripLib;
    ImageView img;
    ImageButton btnReturn;
    RecyclerView listaLibro;
    ArrayList<Libro> listaArrayLibro;
    int id = 0;
    long ids = 0;
    Libro libro;
    boolean correcto = false;
    int cantidad = 0, estado = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mi_prestar_libro);
        txtNombreLib=findViewById(R.id.txtNombreLib);
        txtAutorLib=findViewById(R.id.txtAutorLib);
        txtDescripLib=findViewById(R.id.txtDescripLib);
        txtTitulo=findViewById(R.id.txtTituloAdmin);
        img=findViewById(R.id.imgLibro);
        btndevolver=findViewById(R.id.btnUno);
        btnVer=findViewById(R.id.btnDos);


        btnReturn=findViewById(R.id.btnMenuAdmin);
        txtRol=findViewById(R.id.txtRolActualizar);
        txtNombreA=findViewById(R.id.txtNombreActualizar);
        sp = new SharedPreference(this);
        txtRol.setText(sp.getSharedPreferences("rol"));
        txtNombreA.setText(sp.getSharedPreferences("nombre"));

        //img.setImageResource(R.drawable.ic_eye); //SOLUCIONAR

        if(libro != null) {
            Picasso.get().load(libro.getImagenLi()).error(R.mipmap.ic_launcher_round).into(img);
            txtNombreLib.setText(libro.getNombreLi());
            txtAutorLib.setText(libro.getAutorLi());
            txtDescripLib.setText(libro.getDescripcionLi());
        }

        if(savedInstanceState == null){
            Bundle extras = getIntent().getExtras();
            if(extras == null){
                id = Integer.parseInt(null);
            }else{
                id = extras.getInt("ID");

                DBLibreria libreria = new DBLibreria(MiPrestarLibroActivity.this);

                String titulo1 = extras.getString("titulo").toString();
                if(titulo1.equals("1")){
                    libro = libreria.verLibro(id);
                    if(libro != null) {
                        Picasso.get().load(libro.getImagenLi()).error(R.mipmap.ic_launcher_round).into(img);
                        txtNombreLib.setText(libro.getNombreLi());
                        txtAutorLib.setText(libro.getAutorLi());
                        txtDescripLib.setText(libro.getDescripcionLi());
                    }

                    txtTitulo.setText("Prestar Libro");
                    btndevolver.setText("Prestar");
                    btnVer.setVisibility(View.INVISIBLE);

                    btndevolver.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            libro.setFechaHora(new Date().toString());
                            cantidad = libro.getCantidadLi() - 1;
                            libro.setCantidadLi(cantidad);
                            ids = libreria.prestar(libro, sp.getSharedPreferences("correo"));

                            if(ids > 0) {
                                Toast.makeText(MiPrestarLibroActivity.this, "REGISTRO MODIFICADO", Toast.LENGTH_LONG).show();
                                volver();
                            }else
                            {
                                Toast.makeText(MiPrestarLibroActivity.this, "ERROR AL MODIFICADAR", Toast.LENGTH_LONG).show();
                            }
                        }
                    });

                    btnReturn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            volver();
                        }
                    });
                }else{
                    libro = libreria.verLibroPrestados(id);
                    if(libro != null) {
                        Picasso.get().load(libro.getImagenLi()).error(R.mipmap.ic_launcher_round).into(img);
                        txtNombreLib.setText(libro.getNombreLi());
                        txtAutorLib.setText(libro.getAutorLi());
                        txtDescripLib.setText(libro.getDescripcionLi());
                    }

                    txtTitulo.setText("Mi Libro");

                    btndevolver.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if(libreria.devolver1(libro) && libreria.devolver(libro)) {
                                Toast.makeText(MiPrestarLibroActivity.this, "REGISTRO MODIFICADO", Toast.LENGTH_LONG).show();
                                volver1();
                            }else
                            {
                                Toast.makeText(MiPrestarLibroActivity.this, "ERROR AL MODIFICADAR", Toast.LENGTH_LONG).show();
                            }
                        }
                    });

                    btnReturn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            volver1();
                        }
                    });
                }

                cantidad = 0;
            }
        }else
        {
            id = (int) savedInstanceState.getSerializable("ID");
        }

        btnVer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                leer(id);
            }
        });
    }

    private void volver()
    {
        Intent intent = new Intent(this, LibrosDispoPrestaActivity.class);
        startActivity(intent);
    }

    private void volver1()
    {
        Intent intent = new Intent(this, PagPrincipal.class);
        startActivity(intent);
    }

    private void leer(int id)
    {
        Intent intent = new Intent(this, LeerActivity.class);
        intent.putExtra("ID", id);
        startActivity(intent);
    }
}