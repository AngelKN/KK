package com.cdp.libreriamiguel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cdp.libreriamiguel.DB.DBLibreria;
import com.cdp.libreriamiguel.atributos.Usuario;

public class RegistrarActivity extends AppCompatActivity {

    EditText txtNombre, txtCorreo, txtTelefono, txtDireccion, txtContraseña;
    Button btnRegistrar;
    Usuario use;
    TextView txtVolver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);
        btnRegistrar=findViewById(R.id.btnRegistrar);
        txtNombre=findViewById(R.id.viewNombreR);
        txtCorreo=findViewById(R.id.viewCorreoElectronicoR);
        txtTelefono=findViewById(R.id.viewTelefonoR);
        txtDireccion=findViewById(R.id.viewDireccionR);
        txtContraseña=findViewById(R.id.viewContraseñaR);
        txtVolver=findViewById(R.id.txtMensajeRegistra3);
        use = new Usuario();

        txtVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                volver();
            }
        });

        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long id = 0;
                String ver;
                DBLibreria libreria = new DBLibreria(RegistrarActivity.this);

                if(!txtNombre.getText().toString().equals("")&& !txtCorreo.getText().toString().equals("")&& !txtTelefono.getText().toString().equals("")&& !txtDireccion.getText().toString().equals("")&& !txtContraseña.getText().toString().equals(""))
                {
                    use.setNombre(txtNombre.getText().toString());
                    use.setCorreo(txtCorreo.getText().toString());
                    use.setTelefono(txtTelefono.getText().toString());
                    use.setDireccion(txtDireccion.getText().toString());
                    use.setContraseña(txtContraseña.getText().toString());
                    use.setRol("Usuario");

                    //id = libreria.insertarUsuario(use);
                    ver = libreria.copia(use);
                    if(id > 0)
                    {
                        Toast.makeText(RegistrarActivity.this, "REGISTRO GUARDADO", Toast.LENGTH_LONG).show();
                        volver();
                    }else{
                        Toast.makeText(RegistrarActivity.this, "REGISTRO NO GUARDADO", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(RegistrarActivity.this, "DEBE INGRESAR TODOS LOS CAMPOS", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void volver()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}