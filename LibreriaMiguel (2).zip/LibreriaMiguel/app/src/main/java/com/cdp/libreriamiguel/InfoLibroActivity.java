package com.cdp.libreriamiguel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class InfoLibroActivity extends AppCompatActivity {
    SharedPreference sp;
    TextView txtRol, txtNombreA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_libro);

        txtRol=findViewById(R.id.txtRolActualizar);
        txtNombreA=findViewById(R.id.txtNombreActualizar);
        sp = new SharedPreference(this);
        txtRol.setText(sp.getSharedPreferences("rol"));
        txtNombreA.setText(sp.getSharedPreferences("nombre"));
    }
}