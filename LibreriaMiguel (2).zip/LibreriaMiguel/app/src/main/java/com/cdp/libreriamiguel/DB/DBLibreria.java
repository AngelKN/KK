package com.cdp.libreriamiguel.DB;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.cdp.libreriamiguel.SharedPreference;
import com.cdp.libreriamiguel.atributos.Libro;
import com.cdp.libreriamiguel.atributos.Usuario;

import java.util.ArrayList;

public class DBLibreria extends DBHelper{

    SharedPreference sp;
    Context context;

    public DBLibreria(@Nullable Context context) {
        super(context);
        this.context = context;
        sp = new SharedPreference(context);
    }

    public long insertarUsuario(Usuario use) {
        long id = 0;
        try{
            DBHelper helper = new DBHelper(context);
            SQLiteDatabase db = helper.getWritableDatabase();
            Usuario ver = new Usuario();
            Cursor cr;

            //cr = db.rawQuery("SELECT * FROM " + TABLE_REGISTROS + " WHERE correo = '" + use.getCorreo() + "'",null);
            //ver.setCorreo(cr.getString(2));

            //if(cr.moveToFirst() && !cr.getString(2).equals("123")){
                ContentValues values = new ContentValues();

                values.put("nombre", use.getNombre());
                values.put("correo", use.getCorreo());
                values.put("telefono", use.getTelefono());
                values.put("direccion", use.getDireccion());
                values.put("contraseña", use.getContraseña());
                values.put("rol", use.getRol());

                id = db.insert(TABLE_REGISTROS, null, values);
            //}
        }catch (Exception ex)
        {
            ex.toString();
        }
        return id;
    }

    public String copia(Usuario use) {
        String ver = "";
        try{
            DBHelper helper = new DBHelper(context);
            SQLiteDatabase db = helper.getWritableDatabase();
            Cursor cr;

            cr = db.rawQuery("SELECT * FROM " + TABLE_REGISTROS + " WHERE correo = '" + use.getCorreo() + "'",null);
            if(cr.moveToFirst()){
                ver=cr.getString(2);
            }


            //if(cr.moveToFirst() && !cr.getString(2).equals("123")){
            //}
        }catch (Exception ex)
        {
            ex.toString();
        }
        return ver;
    }

    public Usuario validar(Usuario use) {
        DBHelper helper = new DBHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        boolean validar = false;
        Usuario usuario = null;
        Cursor cr;

        try {
            cr = db.rawQuery("SELECT * FROM " + TABLE_REGISTROS + " WHERE correo = '" + use.getCorreo() + "' AND contraseña = '" + use.getContraseña() + "'",null);
            
            if(cr != null && cr.moveToFirst()){
                do {
                    if(cr.getString(2).equals(use.getCorreo()) && cr.getString(5).equals(use.getContraseña())){
                        usuario = new Usuario();
                        
                        usuario.setId(cr.getInt(0));
                        usuario.setNombre(cr.getString(1));
                        usuario.setCorreo(cr.getString(2));
                        usuario.setTelefono(cr.getString(3));
                        usuario.setDireccion(cr.getString(4));
                        usuario.setContraseña(cr.getString(5));
                        usuario.setRol(cr.getString(6));

                    }
                }while (cr.moveToNext());

                return usuario;
            }
            
        }catch (Exception ex){
            ex.toString();
            usuario = null;
        }

        return usuario;
    }

    public long insertarLibro(Libro lib){
        long id = 0;
        try {
            DBHelper helper = new DBHelper(context);
            SQLiteDatabase db = helper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("nombreLi", lib.getNombreLi());
            values.put("autorLi", lib.getAutorLi());
            values.put("cantidadLi", lib.getCantidadLi());
            values.put("urlLi", lib.getUrlLi());
            values.put("imagenLi", lib.getImagenLi());
            values.put("descripcionLi", lib.getDescripcionLi());

            id = db.insert(TABLE_LIBROS, null, values);
        }catch (Exception ex){
            ex.toString();
        }
        return id;
    }

    public ArrayList<Libro> mostrarDisponibles (){
        DBHelper helper = new DBHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();

        ArrayList<Libro> listaLibro = new ArrayList<>();
        Libro libro;
        Cursor cr;

        cr = db.rawQuery("SELECT * FROM " + TABLE_LIBROS + " WHERE cantidadLi > 0",null);

        if(cr.moveToFirst()){
            do {
                libro = new Libro();

                libro.setId(cr.getInt(0));
                libro.setNombreLi(cr.getString(1));
                libro.setAutorLi(cr.getString(2));
                libro.setCantidadLi(cr.getInt(3));
                libro.setUrlLi(cr.getString(4));
                libro.setImagenLi(cr.getString(5));
                libro.setDescripcionLi(cr.getString(6));

                    listaLibro.add(libro);

            }while(cr.moveToNext());
        }
        cr.close();

        return listaLibro;
    }

    public ArrayList<Libro> mostrarPrestadosUse (String correo){
        DBHelper helper = new DBHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();

        ArrayList<Libro> listaLibro = new ArrayList<>();
        Libro libro;
        Cursor cr;

        cr = db.rawQuery("SELECT * FROM " + TABLE_PRESTADOS + " WHERE correoUs = '" + correo +"'",null);

        if(cr.moveToFirst()){
            do {
                libro = new Libro();

                libro.setId(cr.getInt(0));
                libro.setCorreo(cr.getString(1));
                libro.setFechaHora(cr.getString(2));
                libro.setNombreLi(cr.getString(3));
                libro.setAutorLi(cr.getString(4));
                libro.setCantidadLi(cr.getInt(5));
                libro.setUrlLi(cr.getString(6));
                libro.setImagenLi(cr.getString(7));
                libro.setDescripcionLi(cr.getString(8));


                    listaLibro.add(libro);

            }while(cr.moveToNext());
        }
        cr.close();

        return listaLibro;
    }

    public ArrayList<Libro> mostrarPrestados (){
        DBHelper helper = new DBHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();

        ArrayList<Libro> listaLibro = new ArrayList<>();
        Libro libro;
        Cursor cr;

        cr = db.rawQuery("SELECT * FROM " + TABLE_PRESTADOS + "",null);

        if(cr.moveToFirst()){
            do {
                libro = new Libro();

                libro.setId(cr.getInt(0));
                libro.setCorreo(cr.getString(1));
                libro.setFechaHora(cr.getString(2));
                libro.setNombreLi(cr.getString(3));
                libro.setAutorLi(cr.getString(4));
                libro.setCantidadLi(cr.getInt(5));
                libro.setUrlLi(cr.getString(6));
                libro.setImagenLi(cr.getString(7));
                libro.setDescripcionLi(cr.getString(8));

                listaLibro.add(libro);

            }while(cr.moveToNext());
        }
        cr.close();

        return listaLibro;
    }

    public ArrayList<Libro> mostrarPrestadosLib (String name){
        DBHelper helper = new DBHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();

        ArrayList<Libro> listaLibro = new ArrayList<>();
        Libro libro;
        Cursor cr;

        cr = db.rawQuery("SELECT * FROM " + TABLE_PRESTADOS + " WHERE nombreLi = '" + name + "'",null);

        if(cr.moveToFirst()){
            do {
                libro = new Libro();

                libro.setId(cr.getInt(0));
                libro.setCorreo(cr.getString(1));
                libro.setFechaHora(cr.getString(2));
                libro.setNombreLi(cr.getString(3));
                libro.setAutorLi(cr.getString(4));
                libro.setCantidadLi(cr.getInt(5));
                libro.setUrlLi(cr.getString(6));
                libro.setImagenLi(cr.getString(7));
                libro.setDescripcionLi(cr.getString(8));

                listaLibro.add(libro);

            }while(cr.moveToNext());
        }
        cr.close();

        return listaLibro;
    }

    public Libro verLibro(int id){
        DBLibreria libreria = new DBLibreria(context);
        SQLiteDatabase db = libreria.getWritableDatabase();

        Libro libro = null;
        Cursor cr;

        cr = db.rawQuery("SELECT * FROM " + TABLE_LIBROS + " WHERE id = " + id + " ", null);

        if(cr.moveToFirst()){
            libro = new Libro();

            libro.setId(cr.getInt(0));
            libro.setNombreLi(cr.getString(1));
            libro.setAutorLi(cr.getString(2));
            libro.setCantidadLi(cr.getInt(3));
            libro.setUrlLi(cr.getString(4));
            libro.setImagenLi(cr.getString(5));
            libro.setDescripcionLi(cr.getString(6));
        }

        cr.close();
        return libro;
    }

    public Libro verLibroPrestados(int id){
        DBLibreria libreria = new DBLibreria(context);
        SQLiteDatabase db = libreria.getWritableDatabase();

        Libro libro = null;
        Cursor cr;

        cr = db.rawQuery("SELECT * FROM " + TABLE_PRESTADOS + " WHERE id = " + id + " ", null);

        if(cr.moveToFirst()){
            libro = new Libro();

            libro.setId(cr.getInt(0));
            libro.setCorreo(cr.getString(1));
            libro.setFechaHora(cr.getString(2));
            libro.setNombreLi(cr.getString(3));
            libro.setAutorLi(cr.getString(4));
            libro.setCantidadLi(cr.getInt(5));
            libro.setUrlLi(cr.getString(6));
            libro.setImagenLi(cr.getString(7));
            libro.setDescripcionLi(cr.getString(8));
        }

        cr.close();
        return libro;
    }

    public boolean editarLibro(Libro lib){
        DBHelper helper = new DBHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        boolean correcto = false;

        try{
            db.execSQL("UPDATE " + TABLE_LIBROS + " SET nombreLi = '" + lib.getNombreLi() + "', autorLi = '" + lib.getAutorLi() + "', cantidadLi = " + lib.getCantidadLi() + ", urlLi = '" + lib.getUrlLi() + "', imagenLi = '" + lib.getImagenLi() + "', descripcionLi = '" + lib.getDescripcionLi() + "' WHERE id = '" + lib.getId() + "'");

            correcto = true;
        }catch (Exception ex){
            ex.toString();
            correcto = false;
        }finally {
            db.close();
        }
        return  correcto;
    }

    public long prestar(Libro lib, String correo){
        DBHelper helper = new DBHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        boolean correcto = false;
        long id = 0;

        try{
            db.execSQL("UPDATE " + TABLE_LIBROS + " SET cantidadLi = " + lib.getCantidadLi() + " WHERE id = '" + lib.getId() + "'");

            ContentValues values = new ContentValues();
            values.put("correoUs", correo);
            values.put("fechahora", lib.getFechaHora());
            values.put("nombreLi", lib.getNombreLi());
            values.put("autorLi", lib.getAutorLi());
            values.put("cantidadLi", 1);
            values.put("urlLi", lib.getUrlLi());
            values.put("imagenLi", lib.getImagenLi());
            values.put("descripcionLi", lib.getDescripcionLi());

            id = db.insert(TABLE_PRESTADOS, null, values);

            correcto = true;
        }catch (Exception ex){
            ex.toString();
            id = 0;
        }finally {
            db.close();
        }
        return  id;
    }

    public boolean devolver(Libro lib){
        DBHelper helper = new DBHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        boolean correcto = false;

        try{
            db.execSQL("DELETE FROM "+ TABLE_PRESTADOS +" WHERE id = '"+ lib.getId() +"'");
            correcto = true;
        }catch (Exception ex){
            ex.toString();
            correcto = false;
        }finally {
            db.close();
        }
        return  correcto;
    }

    public boolean devolver1(Libro lib){
        DBHelper helper = new DBHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        boolean correcto = false;
        int vol;
        Libro libro = null;

        try{
            Cursor cr;
            cr = db.rawQuery("SELECT * FROM " + TABLE_LIBROS + " WHERE nombreLi = '" + lib.getNombreLi() + "'",null);
            if(cr.moveToFirst()){
                libro = new Libro();
                libro.setCantidadLi(cr.getInt(3));
            }
            vol = lib.getCantidadLi() + 1;
            db.execSQL("UPDATE " + TABLE_LIBROS + " SET cantidadLi = '" + vol + "' WHERE nombreLi = '" + lib.getNombreLi() + "'");
            correcto = true;
        }catch (Exception ex){
            ex.toString();
            correcto = false;
        }finally {
            db.close();
        }
        return  correcto;
    }
}

