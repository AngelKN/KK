package com.cdp.dbmiguel.L.DB;

import static com.cdp.dbmiguel.L.DB.DBHelperL.TABLE_LOGIN;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.cdp.dbmiguel.DB.DBHelper;
import com.cdp.dbmiguel.atributos.usuario;

public class DBLogin extends DBHelperL {

    Context context;

    public DBLogin(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    public long insertaUsuario(usuario user) //String nombre, String correo, String clave
    {
        long id = 0;
        try{
            DBHelperL dbhelper = new DBHelperL(context);
            SQLiteDatabase db= dbhelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("nombre", user.getNombre());
            values.put("correo", user.getCorreo());
            values.put("clave", user.getClave());

            id = db.insert(TABLE_LOGIN, null,values);
        }catch (Exception ex){
            ex.toString();
        }
        return id;
    }

    /*public Cursor Consultar(String nombre, String clave)
    {
        Cursor cursor = null;
        cursor = this.getReadableDatabase().query(TABLE_LOGIN, new String[]{"Nombre", "Clave"},"nombre like '" + nombre + "' and clave like '" + clave + "'", null, null, null,null,null);
        return cursor;
    }*/

    public boolean validar(usuario user) //String nombre, String clave
    {
        DBHelperL dbhelper = new DBHelperL(context);
        SQLiteDatabase db= dbhelper.getWritableDatabase();
        boolean correcto = false;
        Cursor cr;
        try{
            cr = db.rawQuery("SELECT * FROM "+TABLE_LOGIN+" WHERE nombre = '" + user.getNombre() + "' AND clave = '" + user.getClave() + "'", null);
            if(cr != null && cr.moveToFirst())
            {
                do
                {
                    if(cr.getString(1).equals(user.getNombre()) && cr.getString(3).equals(user.getClave()))
                    {
                        correcto = true;
                    }
                }while (cr.moveToNext());
            }
        }catch (Exception ex){
            ex.toString();
            return correcto = false;
        }finally {
            db.close();
        }
        return correcto;
    }

    /*public usuario user (usuario userv) //String nombre, String clave
    {
        DBHelper dbhelper = new DBHelper(context);
        SQLiteDatabase db= dbhelper.getWritableDatabase();

        usuario user=null;
        Cursor cursoruser;

        cursoruser=db.rawQuery("SELECT * FROM " + TABLE_LOGIN+" nombre = '" + userv.getNombre() + "' AND clave = '" + userv.getClave() + "'", null);

        if(cursoruser.moveToFirst())
        {
            user = new usuario();

            user.setId(cursoruser.getInt(0));
            user.setNombre(cursoruser.getString(1));
            user.setCorreo(cursoruser.getString(2));
            user.setClave(cursoruser.getString(3));
        }
        cursoruser.close();

        return user;
    }*/
}
