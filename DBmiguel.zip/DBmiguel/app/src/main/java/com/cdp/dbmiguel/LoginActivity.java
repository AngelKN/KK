package com.cdp.dbmiguel;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.cdp.dbmiguel.DB.DBHelper;
import com.cdp.dbmiguel.L.DB.DBLogin;
import com.cdp.dbmiguel.atributos.usuario;

public class LoginActivity extends AppCompatActivity {

    Button btnCrear, btnCrear2, btnRegistrar, btnIngreso;
    EditText txtNombre, txtClave;
    SharedPreference sp;
    boolean correcto;
    SharedPreference sharedPreference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        btnRegistrar=findViewById(R.id.btnRegistro);
        //btnCrear=findViewById(R.id.btnIngreso);
        //btnCrear2=findViewById(R.id.btnRegistro);
        txtNombre=findViewById(R.id.txtNombre);
        txtClave=findViewById(R.id.txtClave);
        btnIngreso=findViewById(R.id.btnIngreso);
        correcto = false;
        sp = new SharedPreference(this);
        sharedPreference = new SharedPreference(this);

        DBLogin dbLogin = new DBLogin(LoginActivity.this);


        /*btnCrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelperL dbhelperl = new DBHelperL(LoginActivity.this);
                SQLiteDatabase db = dbhelperl.getWritableDatabase();

                if(db != null)
                {
                    Toast.makeText(LoginActivity.this, "BASE DE DATOS CREADA", Toast.LENGTH_LONG).show();
                }else
                {
                    Toast.makeText(LoginActivity.this, "ERROR AL CREAR BASE DE DATOS", Toast.LENGTH_LONG).show();
                }
            }
        });

        btnCrear2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DBHelper dbhelper = new DBHelper(LoginActivity.this);
                SQLiteDatabase db = dbhelper.getWritableDatabase();

                if(db != null)
                {
                    Toast.makeText(LoginActivity.this, "BASE DE DATOS CREADA", Toast.LENGTH_LONG).show();
                }else
                {
                    Toast.makeText(LoginActivity.this, "ERROR AL CREAR BASE DE DATOS", Toast.LENGTH_LONG).show();
                }

            }
        });*/

        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Registrar();
            }
        });

        btnIngreso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelper dbhelper = new DBHelper(LoginActivity.this);
                SQLiteDatabase db = dbhelper.getWritableDatabase();
                usuario user;
                user = new usuario();
                user.setNombre(txtNombre.getText().toString());
                user.setClave(txtClave.getText().toString());
                correcto = dbLogin.validar(user);
                //user = dbLogin.user(txtNombre.getText().toString(), txtClave.getText().toString());
                //Intent intent = new Intent(MainActivity.this, BienvenidoActicity.class);
                //intent.putExtra("USER", user.getNombre().toString());

                if(correcto)
                {
                    Toast.makeText(LoginActivity.this, "Bienvenido", Toast.LENGTH_LONG).show();
                    sp.setSharedPreferences(user.getNombre().toString());
                    Bienvenido();
                }else
                {
                    Toast.makeText(LoginActivity.this, "Error en usuario o contraseña", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    private void Registrar()
    {
        Intent intent = new Intent(this, RegistroActivity.class);
        startActivity(intent);
    }

    private void Bienvenido()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


}