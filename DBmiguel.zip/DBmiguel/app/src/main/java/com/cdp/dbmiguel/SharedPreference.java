package com.cdp.dbmiguel;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreference {
    Context context;

    SharedPreferences sh;

    SharedPreferences.Editor editor;

    public SharedPreference(Context context) {
        this.context = context;
        sh = context.getSharedPreferences("base_sh", Context.MODE_PRIVATE);
        editor = sh.edit();
    }

    public void setSharedPreferences(String datoGuardar) {
        editor.putString("dato", datoGuardar);
        editor.apply();
    }

    public String getSharedPreferences()
    {
        return sh.getString("dato","dato no encontrado");
    }
}
