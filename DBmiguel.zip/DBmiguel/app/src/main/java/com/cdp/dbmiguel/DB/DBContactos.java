package com.cdp.dbmiguel.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.cdp.dbmiguel.entidades.contactos;

import java.util.ArrayList;

public class DBContactos extends DBHelper{

    Context context;

    public DBContactos(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    public long insertaContacto(contactos cont) //String nombre, String telefono, String correo_electronico
    {
        long id = 0;
        try{
            DBHelper dbhelper = new DBHelper(context);
            SQLiteDatabase db= dbhelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("nombre", cont.getNombre());
            values.put("telefono", cont.getTelefono());
            values.put("nombre_usuario", cont.getNombre_usuario());
            values.put("correo_electronico", cont.getEmail());

            id = db.insert(TABLE_CONTACTOS, null,values);
        }catch (Exception ex){
            ex.toString();
        }

        return id;

    }

    public ArrayList<contactos> mostrarContactos (String cont)
    {
        DBHelper dbhelper = new DBHelper(context);
        SQLiteDatabase db= dbhelper.getWritableDatabase();

        ArrayList<contactos> listaContactos = new ArrayList<>();
        contactos contacto;
        Cursor cursorContactos;

        cursorContactos=db.rawQuery("SELECT * FROM " + TABLE_CONTACTOS + " WHERE nombre_usuario = '" + cont + "'", null);

        if(cursorContactos.moveToFirst())
        {
            do
            {
                contacto = new contactos();

                contacto.setId(cursorContactos.getInt(0));
                contacto.setNombre(cursorContactos.getString(1));
                contacto.setTelefono(cursorContactos.getString(2));
                contacto.setEmail(cursorContactos.getString(3));
                contacto.setNombre_usuario(cursorContactos.getString(4));

                listaContactos.add(contacto);
            }while (cursorContactos.moveToNext());
        }

        cursorContactos.close();

        return listaContactos;

    }

    public contactos verContactos (int id)
    {
        DBHelper dbhelper = new DBHelper(context);
        SQLiteDatabase db= dbhelper.getWritableDatabase();

        contactos contacto=null;
        Cursor cursorContactos;

        cursorContactos=db.rawQuery("SELECT * FROM " + TABLE_CONTACTOS+" WHERE id= "+id+" LIMIT 1", null);

        if(cursorContactos.moveToFirst())
        {
                contacto = new contactos();

                contacto.setId(cursorContactos.getInt(0));
                contacto.setNombre(cursorContactos.getString(1));
                contacto.setTelefono(cursorContactos.getString(2));
                contacto.setEmail(cursorContactos.getString(3));
        }

        cursorContactos.close();

        return contacto;

    }

    public boolean editarContacto(contactos cont) //int id, String nombre, String telefono, String correo_electronico
    {
        DBHelper dbhelper = new DBHelper(context);
        SQLiteDatabase db= dbhelper.getWritableDatabase();
        boolean correcto = false;
        try{
            db.execSQL("UPDATE " + TABLE_CONTACTOS+ " SET nombre = '"+cont.getNombre()+"', Telefono = '"+cont.getTelefono()+"', correo_electronico = '"+cont.getEmail() + "' WHERE id='"+ cont.getId() +"'");

            correcto = true;
        }catch (Exception ex){
            ex.toString();
            correcto = false;
        }finally {
            db.close();
        }

        return correcto;

    }

    public boolean eliminarContacto(int id)
    {
        DBHelper dbhelper = new DBHelper(context);
        SQLiteDatabase db= dbhelper.getWritableDatabase();
        boolean correcto = false;
        try{
            db.execSQL("DELETE FROM "+TABLE_CONTACTOS+" WHERE id='"+id+"'");

            correcto = true;
        }catch (Exception ex){
            ex.toString();
            correcto = false;
        }finally {
            db.close();
        }

        return correcto;

    }

}
