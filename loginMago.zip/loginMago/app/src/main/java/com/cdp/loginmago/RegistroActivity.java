package com.cdp.loginmago;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.cdp.loginmago.DB.DBLogin;

public class RegistroActivity extends AppCompatActivity {

    EditText txtNombreR, txtCorreo, txtClaveR;
    Button btnRegistro2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        txtNombreR=findViewById(R.id.txtNombreR);
        txtCorreo=findViewById(R.id.txtCorreo);
        txtClaveR=findViewById(R.id.txtClaveR);
        btnRegistro2=findViewById(R.id.btnRegistro2);

        btnRegistro2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long id = 0;
                DBLogin dbLogin = new DBLogin(RegistroActivity.this);
                id = dbLogin.insertaUsuario(txtNombreR.getText().toString(), txtCorreo.getText().toString(), txtClaveR.getText().toString());

                if(id > 0)
                {
                    if(!txtNombreR.getText().toString().equals("")&&!txtCorreo.getText().toString().equals("")&&!txtClaveR.getText().toString().equals(""))
                    {
                        Toast.makeText(RegistroActivity.this, "REGISTRO GUARDADO", Toast.LENGTH_LONG).show();
                        limpiar();
                        volver();
                    }else
                    {
                        Toast.makeText(RegistroActivity.this, "DEBE INGRESAR TODOS LOS CAMPOS", Toast.LENGTH_LONG).show();
                    }

                }else
                {
                    Toast.makeText(RegistroActivity.this, "REGISTRO NO GUARDADO", Toast.LENGTH_LONG).show();
                }
            }
        });
    }


    private void limpiar()
    {
        txtNombreR.setText("");
        txtCorreo.setText("");
        txtClaveR.setText("");
    }

    private void volver()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}