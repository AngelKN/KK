package com.cdp.loginmago;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.cdp.loginmago.DB.DBHelper;
import com.cdp.loginmago.DB.DBLogin;
import com.cdp.loginmago.atributos.usuario;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button btnCrear, btnRegistrar, btnIngreso;
    EditText txtNombre, txtClave;
    boolean correcto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnRegistrar=findViewById(R.id.btnRegistro);
        //btnCrear=findViewById(R.id.btnCrear);
        txtNombre=findViewById(R.id.txtNombre);
        txtClave=findViewById(R.id.txtClave);
        btnIngreso=findViewById(R.id.btnIngreso);
        correcto = false;

        DBLogin dbLogin = new DBLogin(MainActivity.this);


        /*btnCrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DBHelper dbhelper = new DBHelper(MainActivity.this);
                SQLiteDatabase db = dbhelper.getWritableDatabase();

                if(db != null)
                {
                    Toast.makeText(MainActivity.this, "BASE DE DATOS CREADA", Toast.LENGTH_LONG).show();
                }else
                {
                    Toast.makeText(MainActivity.this, "ERROR AL CREAR BASE DE DATOS", Toast.LENGTH_LONG).show();
                }

            }
        });¨*/

        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Registrar();
            }
        });

        btnIngreso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelper dbhelper = new DBHelper(MainActivity.this);
                SQLiteDatabase db = dbhelper.getWritableDatabase();
                usuario user;
                user = new usuario();
                correcto = dbLogin.validar(txtNombre.getText().toString(), txtClave.getText().toString());
                //user = dbLogin.user(txtNombre.getText().toString(), txtClave.getText().toString());
                //Intent intent = new Intent(MainActivity.this, BienvenidoActicity.class);
                //intent.putExtra("USER", user.getNombre().toString());

                if(correcto)
                {
                    Toast.makeText(MainActivity.this, "Bienvenido", Toast.LENGTH_LONG).show();
                    Bienvenido();
                }else
                {
                    Toast.makeText(MainActivity.this, "Error en usuario o contraseña", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    private void Registrar()
    {
        Intent intent = new Intent(this, RegistroActivity.class);
        startActivity(intent);
    }

    private void Bienvenido()
    {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }


}