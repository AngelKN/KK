package com.cdp.loginmago.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.cdp.loginmago.atributos.usuario;

public class DBLogin extends DBHelper{

    Context context;

    public DBLogin(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    public long insertaUsuario(String nombre, String correo, String clave)
    {
        long id = 0;
        try{
            DBHelper dbhelper = new DBHelper(context);
            SQLiteDatabase db= dbhelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("nombre", nombre);
            values.put("correo", correo);
            values.put("clave", clave);

            id = db.insert(TABLE_LOGIN, null,values);
        }catch (Exception ex){
            ex.toString();
        }
        return id;
    }

    /*public Cursor Consultar(String nombre, String clave)
    {
        Cursor cursor = null;
        cursor = this.getReadableDatabase().query(TABLE_LOGIN, new String[]{"Nombre", "Clave"},"nombre like '" + nombre + "' and clave like '" + clave + "'", null, null, null,null,null);
        return cursor;
    }*/

    public boolean validar(String nombre, String clave)
    {
        DBHelper dbhelper = new DBHelper(context);
        SQLiteDatabase db= dbhelper.getWritableDatabase();
        boolean correcto = false;
        Cursor cr;
        try{
            cr = db.rawQuery("SELECT * FROM "+TABLE_LOGIN+" WHERE nombre = '" + nombre + "' AND clave = '" + clave + "'", null);
            if(cr != null && cr.moveToFirst())
            {
                do
                {
                    if(cr.getString(1).equals(nombre) && cr.getString(3).equals(clave))
                    {
                        correcto = true;
                    }
                }while (cr.moveToNext());
            }
        }catch (Exception ex){
            ex.toString();
            return correcto = false;
        }finally {
            db.close();
        }
        return correcto;
    }

    public usuario user (String nombre, String clave)
    {
        DBHelper dbhelper = new DBHelper(context);
        SQLiteDatabase db= dbhelper.getWritableDatabase();

        usuario user=null;
        Cursor cursoruser;

        cursoruser=db.rawQuery("SELECT * FROM " + TABLE_LOGIN+" nombre = '" + nombre + "' AND clave = '" + clave + "'", null);

        if(cursoruser.moveToFirst())
        {
            user = new usuario();

            user.setId(cursoruser.getInt(0));
            user.setNombre(cursoruser.getString(1));
            user.setCorreo(cursoruser.getString(2));
            user.setClave(cursoruser.getString(3));
        }
        cursoruser.close();

        return user;
    }
}
