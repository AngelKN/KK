package com.cdp.libreria.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cdp.libreria.R;
import com.cdp.libreria.Tablas.Cliente;

import java.util.ArrayList;

public class ListaClientesAdapter extends RecyclerView.Adapter<ListaClientesAdapter.LibroViewHolder>{

    ArrayList<Cliente> listaClientes;

    public ListaClientesAdapter(ArrayList<Cliente> listaClientes){
        this.listaClientes = listaClientes;
    }

    @NonNull
    @Override
    public ListaClientesAdapter.LibroViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_lista_clientes, null, false);
        return new ListaClientesAdapter.LibroViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListaClientesAdapter.LibroViewHolder holder, int position) {
        holder.primero.setText(listaClientes.get(position).getPrimerCuarto());
        holder.segundo.setText(listaClientes.get(position).getSegundoCuarto());
        holder.tercero.setText(listaClientes.get(position).getTercerCuarto());
        holder.cuarto.setText(listaClientes.get(position).getCuartoCuarto());
        holder.cvv.setText(listaClientes.get(position).getCvv());
        holder.fecha.setText(listaClientes.get(position).getFecha());
        holder.nombre.setText(listaClientes.get(position).getNombre());
    }

    @Override
    public int getItemCount() {
        return listaClientes.size();
    }

    public class LibroViewHolder extends RecyclerView.ViewHolder {

        TextView primero, segundo, tercero, cuarto, cvv, fecha, nombre;
        public LibroViewHolder(@NonNull View itemView) {
            super(itemView);
            primero=itemView.findViewById(R.id.txtPrimero);
            segundo=itemView.findViewById(R.id.txtSegundo);
            tercero=itemView.findViewById(R.id.txtTercero);
            cuarto=itemView.findViewById(R.id.txtCuarto);
            cvv=itemView.findViewById(R.id.txtCvv);
            fecha=itemView.findViewById(R.id.txtFecha);
            nombre=itemView.findViewById(R.id.txtNit);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Context context = view.getContext();
                }
            });
        }
    }
}
