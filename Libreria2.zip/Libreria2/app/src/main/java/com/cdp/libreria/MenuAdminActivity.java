package com.cdp.libreria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MenuAdminActivity extends AppCompatActivity {

    TextView id, rol, nombre;
    ImageButton btnCliente,btnRegistrar,btnConsultarCliente,btnConsultarCorres,btnListCliente,btnListCorres;
    SharedPreferenceBanco sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_admin);
        id=findViewById(R.id.txtId);
        nombre=findViewById(R.id.txtNit);
        rol=findViewById(R.id.txtRol);
        btnCliente=findViewById(R.id.btnCliente);
        btnRegistrar=findViewById(R.id.btnRegistrar);
        btnConsultarCliente=findViewById(R.id.btnConsultarCliente);
        btnConsultarCorres=findViewById(R.id.btnConsultarCorres);
        btnListCliente=findViewById(R.id.btnListCliente);
        btnListCorres=findViewById(R.id.btnListCorres);

        sp = new SharedPreferenceBanco(MenuAdminActivity.this);
        id.setText(sp.getSharedPreferenceBanco("id"));
        rol.setText(sp.getSharedPreferenceBanco("correo"));
        nombre.setText(sp.getSharedPreferenceBanco("nombre"));

        btnCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ReCliente();
            }
        });
        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ReCorres();
            }
        });
        btnConsultarCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id=1;
                Consultar(id);
            }
        });
        btnConsultarCorres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = 2;
                Consultar(id);
            }
        });
        btnListCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = 1;
                Listas(id);
            }
        });
        btnListCorres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = 2;
                Listas(id);

            }
        });
    }

    private void ReCliente()
    {
        Intent intent = new Intent(this, RegistroActivity.class);
        startActivity(intent);
    }

    private void ReCorres()
    {
        Intent intent = new Intent(this, RegistroCorresponsalActivity.class);
        startActivity(intent);
    }

    private void Consultar(int id)
    {
        Intent intent = new Intent(this, IngresarDatoCorresponsalActivity.class);
        intent.putExtra("S", id);
        startActivity(intent);
    }

    private void ConsultarC(int id)
    {
        Intent intent = new Intent(this, IngresarDatoCorresponsalActivity.class);
        intent.putExtra("S", id);
        startActivity(intent);
    }
    private void Listas(int id)
    {
        Intent intent = new Intent(this, ListaClientesActivity.class);
        intent.putExtra("S", id);
        startActivity(intent);
    }
}