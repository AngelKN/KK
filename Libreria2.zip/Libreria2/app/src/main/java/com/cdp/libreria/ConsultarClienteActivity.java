package com.cdp.libreria;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.TextView;

import com.cdp.libreria.Adapters.ListaClientesAdapter;
import com.cdp.libreria.DB.DB;
import com.cdp.libreria.Tablas.Cliente;

import java.util.ArrayList;

public class ConsultarClienteActivity extends AppCompatActivity implements SearchView.OnQueryTextListener{

    TextView id, rol, nombre;
    RecyclerView listaCliente;
    ArrayList<Cliente> listaClientes;
    SharedPreferenceBanco sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultar_cliente);
        listaCliente=findViewById(R.id.listaClientes);
        id=findViewById(R.id.txtId);
        nombre=findViewById(R.id.txtNit);
        rol=findViewById(R.id.txtRol);
        listaCliente.setLayoutManager(new LinearLayoutManager(this));

        sp = new SharedPreferenceBanco(ConsultarClienteActivity.this);
        id.setText(sp.getSharedPreferenceBanco("id"));
        rol.setText(sp.getSharedPreferenceBanco("correo"));
        nombre.setText(sp.getSharedPreferenceBanco("nombre"));

        //buscar.setOnQueryTextListener(this);
        Bundle extras = getIntent().getExtras();
        int id=0;
        id=extras.getInt("ID");

        DB db = new DB(ConsultarClienteActivity.this);
        listaClientes = new ArrayList<>();

        //hay un error, ahora pienso como lo hago tengo sueño
        ListaClientesAdapter adapter = new ListaClientesAdapter(db.mostrarCliente(id));
        listaCliente.setAdapter(adapter);
    }

    @Override
    public boolean onQueryTextSubmit(String s) {

        DB db = new DB(ConsultarClienteActivity.this);
        listaClientes = new ArrayList<>();

        ListaClientesAdapter adapter = new ListaClientesAdapter(db.mostrarCliente(Integer.parseInt(s)));
        listaCliente.setAdapter(adapter);
        return false;
    }

    @Override
    public boolean onQueryTextChange(String s) {
        return false;
    }
}