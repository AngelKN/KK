package com.cdp.libreria.Tablas;

public class Cliente {

    private int id;
    private String Nombre;
    private int cedula;
    private String fecha;
    private double saldo;
    private int cvv;
    private int primerCuarto, segundoCuarto, tercerCuarto, cuartoCuarto;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public int getCvv() {
        return cvv;
    }

    public void setCvv(int cvv) {
        this.cvv = cvv;
    }

    public int getPrimerCuarto() {
        return primerCuarto;
    }

    public void setPrimerCuarto(int primerCuarto) {
        this.primerCuarto = primerCuarto;
    }

    public int getSegundoCuarto() {
        return segundoCuarto;
    }

    public void setSegundoCuarto(int segundoCuarto) {
        this.segundoCuarto = segundoCuarto;
    }

    public int getTercerCuarto() {
        return tercerCuarto;
    }

    public void setTercerCuarto(int tercerCuarto) {
        this.tercerCuarto = tercerCuarto;
    }

    public int getCuartoCuarto() {
        return cuartoCuarto;
    }

    public void setCuartoCuarto(int cuartoCuarto) {
        this.cuartoCuarto = cuartoCuarto;
    }
}
