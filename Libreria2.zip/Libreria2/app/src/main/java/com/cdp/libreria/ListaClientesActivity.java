package com.cdp.libreria;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.SearchView;

import com.cdp.libreria.Adapters.ListaClientesAdapter;
import com.cdp.libreria.Adapters.ListaCorresponsalesAdapter;
import com.cdp.libreria.DB.DB;
import com.cdp.libreria.Tablas.Cliente;
import com.cdp.libreria.Tablas.Corresponsales;

import java.util.ArrayList;

public class ListaClientesActivity extends AppCompatActivity implements SearchView.OnQueryTextListener{

    SearchView buscar;
    RecyclerView listas;
    ArrayList<Cliente> listaCliente;
    ArrayList<Corresponsales> listaCorres;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_clientes2);
        buscar=findViewById(R.id.viewBuscar);
        listas=findViewById(R.id.listaclientes);
        Bundle extras = getIntent().getExtras();
        DB db = new DB(ListaClientesActivity.this);
        listaCliente = new ArrayList<>();
        //buscar.setOnQueryTextListener(this);

        if(extras.getInt("S")==1)
        {
            ListaClientesAdapter adapter = new ListaClientesAdapter(db.listaClinete());
            listas.setAdapter(adapter);
        }else
        {
            listaCorres = new ArrayList<>();
            //otro erroooooooooooooor
            ListaCorresponsalesAdapter adapter = new ListaCorresponsalesAdapter(db.listaCorres());
            listas.setAdapter(adapter);

        }

    }

    @Override
    public boolean onQueryTextSubmit(String s) {

        DB db = new DB(ListaClientesActivity.this);
        listaCliente = new ArrayList<>();

        ListaClientesAdapter adapter = new ListaClientesAdapter(db.mostrarCliente(Integer.parseInt(s)));
        listas.setAdapter(adapter);
        return false;
    }

    @Override
    public boolean onQueryTextChange(String s) {
        return false;
    }
}