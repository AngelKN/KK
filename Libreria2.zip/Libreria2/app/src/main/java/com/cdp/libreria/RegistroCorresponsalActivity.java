package com.cdp.libreria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.cdp.libreria.DB.DB;
import com.cdp.libreria.Tablas.Corresponsales;

public class RegistroCorresponsalActivity extends AppCompatActivity {

    TextView nombre, correo, nit, clave, saldo;
    Button btnRegistro, btnCancelar;

    Corresponsales cor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_corresponsal);
        nombre=findViewById(R.id.viewCorres);
        nit=findViewById(R.id.viewNit);
        clave=findViewById(R.id.viewClave);
        saldo=findViewById(R.id.viewSaldo);
        btnRegistro=findViewById(R.id.btnRegistro);
        btnCancelar=findViewById(R.id.btnCancelar);

        cor = new Corresponsales();

        btnRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long id = 0;
                DB db = new DB(RegistroCorresponsalActivity.this);

                if(!nombre.getText().toString().equals("") && !nit.getText().toString().equals("") && !clave.getText().toString().equals("") && !saldo.getText().toString().equals("") ){

                    cor.setCorresponal(nombre.getText().toString());
                    cor.setNit(Integer.parseInt(nit.getText().toString()));
                    cor.setCorreo(nombre.getText().toString()+"@wposs.com");
                    cor.setClave(clave.getText().toString());
                    cor.setSaldo(Double.parseDouble(saldo.getText().toString()));
                    cor.setEstado("ACTIVO");

                    if(!db.veriCorres(cor.getNit(), cor.getCorresponal())){
                        id = db.insertarCorres(cor);

                        if(id > 0)
                        {
                            Toast.makeText(RegistroCorresponsalActivity.this, "SE REGISTRO CORRECTAMENTE", Toast.LENGTH_LONG).show();

                            nombre.setText("");
                            nit.setText("");
                            correo.setText("");
                            clave.setText("");
                            saldo.setText("");

                            volver();
                        }else
                        {
                            Toast.makeText(RegistroCorresponsalActivity.this, "HUBO UN ERROR AL REGISTRARSE", Toast.LENGTH_LONG).show();
                        }
                    }else
                    {
                        Toast.makeText(RegistroCorresponsalActivity.this, "EXITE UN REGISTRO CON ESTE CORREO", Toast.LENGTH_LONG).show();
                        correo.setText("");
                    }

                }else
                {
                    Toast.makeText(RegistroCorresponsalActivity.this, "DEBE LLENAR TODOS LOS CAMPOS", Toast.LENGTH_LONG).show();
                }
            }
        });

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                volver();
            }
        });

    }

    private void volver()
    {
        Intent intent = new Intent(this, MenuAdminActivity.class);
        startActivity(intent);
    }
}