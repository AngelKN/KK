package com.cdp.libreria;

import static android.os.Build.VERSION_CODES.S;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class IngresarDatoCorresponsalActivity extends AppCompatActivity {

    EditText nit;
    TextView titulo;
    Button btnConsultar, btnCancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingresar_dato_corresponsal);
        nit=findViewById(R.id.viewNitConsultar);
        titulo=findViewById(R.id.txtRegistro2);
        btnConsultar=findViewById(R.id.btnConsultar);
        btnCancelar=findViewById(R.id.btnCancelar);

        Bundle extras = getIntent().getExtras();
        if(extras.getInt("S")==1){
            titulo.setText("Consultar Cliente");
            nit.setHint("Numero de Cedula a Consultar");
        }if(extras.getInt("S")==2){
            titulo.setText("Consultar Corresponsal");
            nit.setHint("Numero de Nit a Consultar");
        }if(extras.getInt("S")==3){
            titulo.setText("Consultar Saldo");
            nit.setHint("Numero de Cedula a Consultar");
        }

        btnConsultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!nit.getText().toString().equals(""))
                {
                    int s = extras.getInt("S");
                    consultarc(Integer.parseInt(nit.getText().toString()), s);
                }
                    nit.setText("");

            }
        });

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancelar();
            }
        });

    }

    private void consultarc(int id, int s)
    {
        Intent intent = new Intent(this, ConsultarCorresponsalActivity.class);
        intent.putExtra("ID", id);
        intent.putExtra("S", s);
        startActivity(intent);
    }

    private void cancelar()
    {
        Intent intent = new Intent(this, MenuAdminActivity.class);
        startActivity(intent);
    }
}