package com.cdp.libreria.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.cdp.libreria.CrearDB.CrearDB;
import com.cdp.libreria.Tablas.Banco;
import com.cdp.libreria.Tablas.Corresponsales;
import com.cdp.libreria.Tablas.Cliente;

import java.util.ArrayList;

public class DB extends CrearDB {

    Context context;

    public DB(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    public Corresponsales validarCorres(String correo, String clave) {
        CrearDB helper = new CrearDB(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        Cursor cr;
        Corresponsales corre = new Corresponsales();

        try {
            cr = db.rawQuery("SELECT * FROM " + TABLE_CORRESPONSAL + " WHERE correo = '" + correo + "' AND clave = '" + clave + "' AND estado = 'ACTIVO' LIMIT 1",null);

            if(cr != null && cr.moveToFirst()){
                corre.setId(cr.getInt(0));
                corre.setSaldo(cr.getInt(1));
                corre.setCorresponal(cr.getString(2));
                corre.setCorreo(cr.getString(3));
                corre.setClave(cr.getString(4));
                corre.setSaldo(cr.getDouble(5));
                corre.setEstado(cr.getString(6));
            }else
            {
                corre=null;
            }

        }catch (Exception ex){
            ex.toString();
        }

        return corre;
    }

    public Banco validarBanco(String correo, String clave) {
        CrearDB helper = new CrearDB(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        Cursor cr;
        Banco corre = new Banco();

        try {
            cr = db.rawQuery("SELECT * FROM " + TABLE_BANCO + " WHERE correo = '" + correo + "' AND clave = '" + clave + "' LIMIT 1",null);

            if(cr != null && cr.moveToFirst()){
                corre.setId(cr.getInt(0));
                corre.setBanco(cr.getString(1));
                corre.setCorreo(cr.getString(2));
                corre.setClave(cr.getString(3));
            }else
            {
                corre=null;
            }

        }catch (Exception ex){
            ex.toString();
        }

        return corre;
    }

    public boolean veriCorres(int nit, String corresponsal) {
        CrearDB helper = new CrearDB(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        boolean validar = false;
        Cursor cr;

        try {
            cr = db.rawQuery("SELECT * FROM " + TABLE_CORRESPONSAL + " WHERE nit = " + nit + " AND corresponsal = '" + corresponsal + "' AND estado = 'ACTIVO' LIMIT 1",null);

            if(cr != null && cr.moveToFirst()){
                validar = true;
            }

        }catch (Exception ex){
            ex.toString();
        }

        return validar;
    }

    public boolean veriCliente(Cliente cli) {
        CrearDB helper = new CrearDB(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        boolean validar = false;
        Cursor cr;

        try {
            cr = db.rawQuery("SELECT * FROM " + TABLE_CLIENTE + " WHERE cvv = '" + cli.getCvv() + "' AND cedula = '" + cli.getCedula() + "' AND primerCuarto = '" + cli.getPrimerCuarto() + "' AND segundoCuarto = '" + cli.getSegundoCuarto() + "' AND tercerCuarto = '" + cli.getTercerCuarto() + "' AND cuartoCuarto = '" + cli.getCuartoCuarto() + "' LIMIT 1",null);

            if(cr != null && cr.moveToFirst()){
                validar = true;
            }

        }catch (Exception ex){
            ex.toString();
        }

        return validar;
    }

    public Cliente validarCliente(int cedula, int cvv) {
        CrearDB helper = new CrearDB(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        boolean validar = false;
        Cursor cr;
        Cliente cli = new Cliente();

        try {
            cr = db.rawQuery("SELECT * FROM " + TABLE_CLIENTE + " WHERE cvv = '" + cvv + "' AND cedula = '" + cedula + "' LIMIT 1",null);

            if(cr != null && cr.moveToFirst()){
                cli.setId(cr.getInt(0));
                cli.setCedula(cr.getInt(1));
                cli.setNombre(cr.getString(2));
                cli.setFecha(cr.getString(3));
                cli.setSaldo(cr.getDouble(4));
                cli.setCvv(cr.getInt(5));
                cli.setPrimerCuarto(cr.getInt(6));
                cli.setSegundoCuarto(cr.getInt(7));
                cli.setTercerCuarto(cr.getInt(8));
                cli.setCuartoCuarto(cr.getInt(9));
            }else
            {
                cli=null;
            }

        }catch (Exception ex){
            ex.toString();
        }

        return cli;
    }

    public long insertarCliente(Cliente use) {
        long id = 0;
        try{
            CrearDB crear = new CrearDB(context);
            SQLiteDatabase db = crear.getWritableDatabase();
            ContentValues values = new ContentValues();

                values.put("cedula", use.getCedula());
                values.put("nombre", use.getNombre());
                values.put("fecha", use.getFecha());
                values.put("saldo", use.getSaldo());
                values.put("cvv", use.getCvv());
                values.put("primerCuarto", use.getPrimerCuarto());
                values.put("segundoCuarto", use.getSegundoCuarto());
                values.put("tercerCuarto", use.getTercerCuarto());
                values.put("cuartoCuarto", use.getCuartoCuarto());

                id = db.insert(TABLE_CLIENTE, null, values);
        }catch (Exception ex)
        {
            ex.toString();
        }
        return id;
    }

    public long insertarCorres(Corresponsales corre) {
        long id = 0;
        try{
            CrearDB crear = new CrearDB(context);
            SQLiteDatabase db = crear.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put("nit", corre.getNit());
            values.put("corresponsal", corre.getCorresponal());
            values.put("correo", corre.getCorreo());
            values.put("clave", corre.getClave());
            values.put("saldo", corre.getSaldo());
            values.put("estado", corre.getEstado());

            id = db.insert(TABLE_CORRESPONSAL, null, values);
        }catch (Exception ex)
        {
            ex.toString();
        }
        return id;
    }

    public ArrayList<Cliente> mostrarCliente (int cedula){
        CrearDB crear = new CrearDB(context);
        SQLiteDatabase db = crear.getWritableDatabase();

        ArrayList<Cliente> listaCliente = new ArrayList<>();
        Cliente cliente;
        Cursor cr;

        cr = db.rawQuery("SELECT * FROM " + TABLE_CLIENTE + " WHERE cedula = "+ cedula +"",null);

        if(cr.moveToFirst()){
            do {
                cliente = new Cliente();

                cliente.setId(cr.getInt(0));
                cliente.setNombre(cr.getString(1));
                cliente.setCedula(cr.getInt(2));
                cliente.setFecha(cr.getString(3));
                cliente.setSaldo(cr.getDouble(4));
                cliente.setCvv(cr.getInt(5));
                cliente.setPrimerCuarto(cr.getInt(6));
                cliente.setSegundoCuarto(cr.getInt(7));
                cliente.setTercerCuarto(cr.getInt(8));
                cliente.setCuartoCuarto(cr.getInt(9));

                listaCliente.add(cliente);

            }while(cr.moveToNext());
        }
        cr.close();

        return listaCliente;
    }

    public ArrayList<Cliente> listaClinete (){
        CrearDB crear = new CrearDB(context);
        SQLiteDatabase db = crear.getWritableDatabase();

        ArrayList<Cliente> listaCliente = new ArrayList<>();
        Cliente cliente;
        Cursor cr;

        cr = db.rawQuery("SELECT * FROM " + TABLE_CLIENTE ,null);

        if(cr.moveToFirst()){
            do {
                cliente = new Cliente();

                cliente.setId(cr.getInt(0));
                cliente.setNombre(cr.getString(1));
                cliente.setCedula(cr.getInt(2));
                cliente.setFecha(cr.getString(3));
                cliente.setSaldo(cr.getDouble(4));
                cliente.setCvv(cr.getInt(5));
                cliente.setPrimerCuarto(cr.getInt(6));
                cliente.setSegundoCuarto(cr.getInt(7));
                cliente.setTercerCuarto(cr.getInt(8));
                cliente.setCuartoCuarto(cr.getInt(9));

                listaCliente.add(cliente);

            }while(cr.moveToNext());
        }
        cr.close();

        return listaCliente;
    }

    public ArrayList<Corresponsales> mostrarCorres (int nit){
        CrearDB crear = new CrearDB(context);
        SQLiteDatabase db = crear.getWritableDatabase();

        ArrayList<Corresponsales> listaCorres = new ArrayList<>();
        Corresponsales corre;
        Cursor cr;

        cr = db.rawQuery("SELECT * FROM " + TABLE_CORRESPONSAL + " WHERE nit = "+ nit +"",null);

        if(cr.moveToFirst()){
            do {
                corre = new Corresponsales();

                corre.setId(cr.getInt(0));
                corre.setNit(cr.getInt(1));
                corre.setCorresponal(cr.getString(2));
                corre.setCorreo(cr.getString(3));
                corre.setClave(cr.getString(4));
                corre.setSaldo(cr.getDouble(5));
                corre.setEstado(cr.getString(6));

                listaCorres.add(corre);

            }while(cr.moveToNext());
        }
        cr.close();

        return listaCorres;
    }

    public ArrayList<Corresponsales> listaCorres (){
        CrearDB crear = new CrearDB(context);
        SQLiteDatabase db = crear.getReadableDatabase();

        ArrayList<Corresponsales> listaCorres = new ArrayList<>();
        Corresponsales corre;
        Cursor cr;

        cr = db.rawQuery("SELECT * FROM " + TABLE_CORRESPONSAL,null);

        if(cr.moveToFirst()){
            do {
                corre = new Corresponsales();

                corre.setId(cr.getInt(0));
                corre.setNit(cr.getInt(1));
                corre.setCorresponal(cr.getString(2));
                corre.setCorreo(cr.getString(3));
                corre.setClave(cr.getString(4));
                corre.setSaldo(cr.getDouble(5));
                corre.setEstado(cr.getString(6));

                listaCorres.add(corre);

            }while(cr.moveToNext());
        }
        cr.close();

        return listaCorres;
    }

}
