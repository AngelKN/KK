package com.cdp.libreria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.cdp.libreria.CrearDB.CrearDB;
import com.cdp.libreria.DB.DB;
import com.cdp.libreria.Tablas.Banco;
import com.cdp.libreria.Tablas.Corresponsales;

public class MainActivity extends AppCompatActivity {

    Button btnLogin;
    TextView btnRegistro, correo, clave;
    SharedPreference sp;
    SharedPreferenceBanco spb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnLogin=findViewById(R.id.btnLogin);
        correo=findViewById(R.id.viewCorreo);
        clave=findViewById(R.id.viewClave);

        sp = new SharedPreference(MainActivity.this);
        spb = new SharedPreferenceBanco(MainActivity.this);
        DB db = new DB(MainActivity.this);

        /*btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CrearDB helper = new CrearDB(MainActivity.this);

                SQLiteDatabase db = helper.getWritableDatabase();
                ContentValues values = new ContentValues();


                if(db != null)
                {
                    Toast.makeText(MainActivity.this, "BASE DE DATOS CREADA", Toast.LENGTH_LONG).show();
                }else
                {
                    Toast.makeText(MainActivity.this, "ERROR AL CREAR BASE DE DATOS", Toast.LENGTH_LONG).show();
                }

            }
        });*/

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!correo.getText().toString().equals("") && !clave.getText().toString().equals("") ){

                    String correoV = correo.getText().toString();
                    String claveV = clave.getText().toString();

                    Corresponsales corre;
                    Banco banco;
                    corre=db.validarCorres(correoV,claveV);
                    banco=db.validarBanco(correoV,claveV);

                    if(corre!=null){
                        Toast.makeText(MainActivity.this, "SE INGRESO CORRECTAMENTE", Toast.LENGTH_LONG).show();
                        sp.setSharedPreferences(corre);
                        correo.setText("");
                        clave.setText("");
                        menucorresponsal();
                    }if(banco!=null){
                        Toast.makeText(MainActivity.this, "SE INGRESO CORRECTAMENTE", Toast.LENGTH_LONG).show();
                        spb.setSharedPreferenceBanco(banco);
                        correo.setText("");
                        clave.setText("");
                        menuadmin();
                    }else
                    {
                            Toast.makeText(MainActivity.this, "HUBO UN ERROR AL INGRESAR", Toast.LENGTH_LONG).show();
                            correo.setText("");
                            clave.setText("");
                    }

                }else
                {
                    Toast.makeText(MainActivity.this, "DEBE LLENAR TODOS LOS CAMPOS", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    private void registro()
    {
        Intent intent = new Intent(this, RegistroActivity.class);
        startActivity(intent);
    }

    private void menuadmin()
    {
        Intent intent = new Intent(this, MenuAdminActivity.class);
        startActivity(intent);
    }
    private void menucorresponsal()
    {
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }
}