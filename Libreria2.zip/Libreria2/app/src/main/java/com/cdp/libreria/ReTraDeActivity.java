package com.cdp.libreria;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class ReTraDeActivity extends AppCompatActivity {

    TextView titulo, id, rol, nombre;
    EditText uno,dos,tres;
    SharedPreferenceBanco sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_re_tra_de);
        titulo=findViewById(R.id.txtTitulo);
        id=findViewById(R.id.txtCorresponsal);
        nombre=findViewById(R.id.txtNombre);
        rol=findViewById(R.id.txtSaldo);
        uno=findViewById(R.id.viewUno);
        dos=findViewById(R.id.viewDos);
        tres=findViewById(R.id.viewTres);

        sp = new SharedPreferenceBanco(ReTraDeActivity.this);
        id.setText(sp.getSharedPreferenceBanco("id"));
        rol.setText(sp.getSharedPreferenceBanco("correo"));
        nombre.setText(sp.getSharedPreferenceBanco("nombre"));

        Bundle extras = getIntent().getExtras();
        if(extras.getInt("S")==1){
            titulo.setText("Retiros");
            uno.setVisibility(View.VISIBLE);
            dos.setVisibility(View.VISIBLE);
            uno.setHint("Numero de Cedula");
            dos.setHint("Monto a Retirar");
        }if(extras.getInt("S")==2){
            titulo.setText("Depositos");
            uno.setVisibility(View.VISIBLE);
            dos.setVisibility(View.VISIBLE);
            tres.setVisibility(View.VISIBLE);
            uno.setHint("Numero de Cedula a Depositar");
            dos.setHint("Numero de Cedula que Deposita");
            tres.setHint("Monto a Deositar");
        }if(extras.getInt("S")==3){
            titulo.setText("Tranferencia");
            uno.setVisibility(View.VISIBLE);
            dos.setVisibility(View.VISIBLE);
            tres.setVisibility(View.VISIBLE);
            uno.setHint("Numero de Cedula a Transferir");
            dos.setHint("MoNumero de Cedula que Transfiere");
            tres.setHint("Monto a Transferir");
        }
    }
}