package com.cdp.libreria.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cdp.libreria.R;
import com.cdp.libreria.SharedPreferenceBanco;
import com.cdp.libreria.Tablas.Cliente;
import com.cdp.libreria.Tablas.Corresponsales;

import java.util.ArrayList;

public class ListaCorresponsalesAdapter extends RecyclerView.Adapter<ListaCorresponsalesAdapter.LibroViewHolder>{

    ArrayList<Corresponsales> listaCorres;
    SharedPreferenceBanco sp;

    public ListaCorresponsalesAdapter(ArrayList<Corresponsales> listaCorres){
        this.listaCorres = listaCorres;
    }
    @NonNull
    @Override
    public ListaCorresponsalesAdapter.LibroViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_lista_corresponsal, null, false);
        return new ListaCorresponsalesAdapter.LibroViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListaCorresponsalesAdapter.LibroViewHolder holder, int position) {
        holder.nombre.setText(listaCorres.get(position).getCorresponal());
        holder.nit.setText(""+listaCorres.get(position).getNit());
        holder.saldo.setText(""+listaCorres.get(position).getSaldo());
        holder.correo.setText(""+listaCorres.get(position).getCorreo());
    }

    @Override
    public int getItemCount() {
        return listaCorres.size();
    }

    public class LibroViewHolder extends RecyclerView.ViewHolder {
        TextView nombre, nit, saldo, correo;

        public LibroViewHolder(@NonNull View itemView) {
            super(itemView);

            nombre=itemView.findViewById(R.id.txtNombre);
            nit=itemView.findViewById(R.id.txtNitCon);
            saldo=itemView.findViewById(R.id.txtSaldo);
            correo=itemView.findViewById(R.id.txtCorreo);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Context context = view.getContext();
                }
            });
        }
    }
}
