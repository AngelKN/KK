package com.cdp.libreria;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.TextView;

import com.cdp.libreria.Adapters.ListaClientesAdapter;
import com.cdp.libreria.Adapters.ListaCorresponsalesAdapter;
import com.cdp.libreria.DB.DB;
import com.cdp.libreria.Tablas.Cliente;

import java.util.ArrayList;

public class ConsultarCorresponsalActivity extends AppCompatActivity {

    TextView id, rol, nombre;
    RecyclerView listaCorre;
    ArrayList<Cliente> listaCorres;
    SharedPreferenceBanco sp;
    TextView titulo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultar_corresponsal);
        listaCorre=findViewById(R.id.listaClientes);
        id=findViewById(R.id.txtId);
        nombre=findViewById(R.id.txtNit);
        rol=findViewById(R.id.txtRol);
        titulo=findViewById(R.id.txtRegistro5);
        listaCorre.setLayoutManager(new LinearLayoutManager(this));

        sp = new SharedPreferenceBanco(ConsultarCorresponsalActivity.this);
        id.setText(sp.getSharedPreferenceBanco("id"));
        rol.setText(sp.getSharedPreferenceBanco("correo"));
        nombre.setText(sp.getSharedPreferenceBanco("nombre"));

        Bundle extras = getIntent().getExtras();
        int id=0;
        id=extras.getInt("ID");
        if(extras.getInt("S")==1){
            titulo.setText("Consultar Cliente");
        }

        if(extras.getInt("S")==1)
        {
            DB db = new DB(ConsultarCorresponsalActivity.this);
            listaCorres = new ArrayList<>();

            //hay un error, ahora pienso como lo hago tengo sueño
            ListaClientesAdapter adapter = new ListaClientesAdapter(db.mostrarCliente(id));
            listaCorre.setAdapter(adapter);
        }else{
            DB db = new DB(ConsultarCorresponsalActivity.this);
            listaCorres = new ArrayList<>();

            ListaCorresponsalesAdapter adapter = new ListaCorresponsalesAdapter(db.mostrarCorres(id));
            listaCorre.setAdapter(adapter);
        }

    }
}