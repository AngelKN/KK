package com.cdp.libreria.CrearDB;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class CrearDB extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NOMBRE = "Corresponsal.db";
    public static final String TABLE_CORRESPONSAL = "corresponsal";
    public static final String TABLE_CLIENTE = "clientes";
    public static final String TABLE_BANCO = "bancos";
    public static final String TABLE_TRANSACCION = "transacciones";

    public CrearDB(@Nullable Context context) {
        super(context, DATABASE_NOMBRE, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE "+TABLE_BANCO+"("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "banco TEXT not null,"+
                "correo TEXT not null,"+
                "clave TEXT NOT NULL)");

        ContentValues values = new ContentValues();
        values.put("banco", "Carlos Marquez");
        values.put("correo", "admin@wposs.com");
        values.put("clave", "Admin123*");
        sqLiteDatabase.insert(TABLE_BANCO, null, values);

        sqLiteDatabase.execSQL("CREATE TABLE "+TABLE_CORRESPONSAL+"("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "nit INTEGER not null,"+
                "corresponsal TEXT not null,"+
                "correo TEXT not null,"+
                "clave TEXT NOT NULL,"+
                "saldo INTEGER NOT NULL,"+
                "estado TEXT NOT NULL)");

        sqLiteDatabase.execSQL("CREATE TABLE "+TABLE_CLIENTE+"("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "cedula INTEGER not null,"+
                "nombre TEXT not null,"+
                "fecha TEXT NOT NULL," +
                "saldo INTEGER NOT NULL," +
                "cvv INTEGER NOT NULL,"+
                "primerCuarto INTEGER NOT NULL,"+
                "segundoCuarto INTEGER NOT NULL,"+
                "tercerCuarto INTEGER NOT NULL,"+
                "cuartoCuarto INTEGER NOT NULL)");

        sqLiteDatabase.execSQL("CREATE TABLE "+TABLE_TRANSACCION+"("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "fecha TEXT not null,"+
                "tipo TEXT not null,"+
                "monto INTGER not null,"+
                "cedula INTGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
