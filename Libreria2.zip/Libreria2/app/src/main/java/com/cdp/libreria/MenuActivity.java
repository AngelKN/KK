package com.cdp.libreria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MenuActivity extends AppCompatActivity {

    TextView id, rol, nombre;
    ImageButton btnPagos,btnRetiros,btnDepositos,btnTranferencias,btnHistorial,btnConsulta;
    SharedPreference sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        id=findViewById(R.id.txtCorresponsal);
        nombre=findViewById(R.id.txtNombre);
        rol=findViewById(R.id.txtSaldo);
        btnPagos=findViewById(R.id.btnPago);
        btnRetiros=findViewById(R.id.btnRetiros);
        btnDepositos=findViewById(R.id.btnDepositos);
        btnTranferencias=findViewById(R.id.btnTranferencias);
        btnHistorial=findViewById(R.id.btnHistorial);
        btnConsulta=findViewById(R.id.btnConsultas);

        sp = new SharedPreference(MenuActivity.this);
        id.setText(sp.getSharedPreferences("id"));
        rol.setText(sp.getSharedPreferences("correo"));
        nombre.setText(sp.getSharedPreferences("nombre"));

        btnPagos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        btnRetiros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = 1;
                ReTraDe(id);
            }
        });
        btnDepositos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = 2;
                ReTraDe(id);
            }
        });
        btnTranferencias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = 3;
                ReTraDe(id);
            }
        });
        btnHistorial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        btnConsulta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = 3;
                Saldo(id);
            }
        });

    }

    private void registro()
    {
        Intent intent = new Intent(this, RegistroActivity.class);
        startActivity(intent);
    }

    private void menu()
    {
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }
    private void Saldo(int id )
    {
        Intent intent = new Intent(this, IngresarDatoCorresponsalActivity.class);
        intent.putExtra("S", id);
        startActivity(intent);
    }

    private void ReTraDe(int id )
    {
        Intent intent = new Intent(this, ReTraDeActivity.class);
        intent.putExtra("S", id);
        startActivity(intent);
    }
}