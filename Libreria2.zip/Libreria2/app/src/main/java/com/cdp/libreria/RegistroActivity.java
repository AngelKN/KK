package com.cdp.libreria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.cdp.libreria.DB.DB;
import com.cdp.libreria.Tablas.Cliente;

import java.util.Date;

public class RegistroActivity extends AppCompatActivity {

    TextView nombre, cedula, saldo;
    Button btnRegistro, btnCancelar;

    Cliente use;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        nombre=findViewById(R.id.viewNombre);
        cedula=findViewById(R.id.viewCedula);
        saldo=findViewById(R.id.viewSaldo);
        btnRegistro=findViewById(R.id.btnRegistro);
        btnCancelar=findViewById(R.id.btnCancelar);

        use = new Cliente();

        btnRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long id = 0;
                DB db = new DB(RegistroActivity.this);

                if(!nombre.getText().toString().equals("") && !cedula.getText().toString().equals("") && !saldo.getText().toString().equals("") ){

                    use.setNombre(nombre.getText().toString());
                    use.setCedula(Integer.parseInt(cedula.getText().toString()));
                    use.setFecha(new Date().toString());
                    use.setSaldo(Double.parseDouble(saldo.getText().toString()));
                    use.setCvv((int) (Math.random() * 999) + 100);
                    use.setPrimerCuarto((int) (Math.random() * 9999) + 1000);
                    use.setSegundoCuarto((int) (Math.random() * 9999) + 1000);
                    use.setTercerCuarto((int) (Math.random() * 9999) + 1000);
                    use.setCuartoCuarto((int) (Math.random() * 9999) + 1000);
                    String numeroCompleto = use.getPrimerCuarto() + " " + use.getSegundoCuarto() + " " + use.getTercerCuarto() + " " + use.getCuartoCuarto();

                    if(!db.veriCliente(use)){
                        id = db.insertarCliente(use);

                        if(id > 0)
                        {
                            Toast.makeText(RegistroActivity.this, "SE REGISTRO CORRECTAMENTE", Toast.LENGTH_LONG).show();

                            nombre.setText("");
                            cedula.setText("");
                            saldo.setText("");

                            volver();
                        }else
                        {
                            Toast.makeText(RegistroActivity.this, "HUBO UN ERROR AL REGISTRARSE", Toast.LENGTH_LONG).show();
                        }
                    }else
                    {
                        Toast.makeText(RegistroActivity.this, "EXITE UN REGISTRO CON ESTA CEDULA", Toast.LENGTH_LONG).show();
                        cedula.setText("");
                    }

                }else
                {
                    Toast.makeText(RegistroActivity.this, "DEBE LLENAR TODOS LOS CAMPOS", Toast.LENGTH_LONG).show();
                }
            }
        });

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                volver();
            }
        });
    }

    private void volver()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}