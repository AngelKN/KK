package com.service.service;

import java.util.ArrayList;
import java.util.Optional;

import com.service.model.Usuario;

public interface UsuarioService {

	ArrayList<Usuario> getAllUser(String nombre);

	Optional<Usuario> getUserById(Long id);

	Usuario saveUser(Usuario u);

	boolean deleteUserById(Long id);

}
