package com.service.controller;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.service.model.Usuario;
import com.service.service.UsuarioService;

@RestController
@RequestMapping("api")
public class Controller {

	@Autowired
	UsuarioService usuarioService;

	@GetMapping("/saludar")
	public String saludar() {
		return "Myaaaaaauuuu";
	}

	@GetMapping("/all")
	public ArrayList<Usuario> getAllUser() {
		String nombre = "";
		return usuarioService.getAllUser(nombre);
	}

	@GetMapping("/find/{id}")
	public Optional<Usuario> getUserById(@PathVariable("id") long id) {
		return usuarioService.getUserById(id);
	}

	@PostMapping("/save")
	public Usuario saveUser(@RequestBody Usuario u) {
		return usuarioService.saveUser(u);
	}

	@DeleteMapping("/delete/{id}")
	public Optional<Usuario> deleteUserById(@PathVariable("id") long id) {
		Optional<Usuario> u = usuarioService.getUserById(id);
		usuarioService.deleteUserById(id);
		return u;
	}

}
