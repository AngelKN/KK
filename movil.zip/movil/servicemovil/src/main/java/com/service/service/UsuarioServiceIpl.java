package com.service.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.service.model.Usuario;
import com.service.repository.UsuarioRepository;

@Service
public class UsuarioServiceIpl implements UsuarioService {

	@Autowired
	UsuarioRepository usuarioRepository;

	@Override
	public ArrayList<Usuario> getAllUser(String nombre) {
		// TODO Auto-generated method stub
		if(nombre != null)
		{
			return (ArrayList<Usuario>) usuarioRepository.findAll(nombre);
		}
		return (ArrayList<Usuario>) usuarioRepository.findAll();
	}

	@Override
	public Optional<Usuario> getUserById(Long id) {
		// TODO Auto-generated method stub
		return usuarioRepository.findById(id);
	}

	@Override
	public Usuario saveUser(Usuario u) {
		// TODO Auto-generated method stub
		return usuarioRepository.save(u);
	}

	@Override
	public boolean deleteUserById(Long id) {
		// TODO Auto-generated method stub
		try {
			Optional<Usuario> u = getUserById(id);
			usuarioRepository.delete(u.get());
			return true;
		} catch (Exception e) {
			return false;
		}
	}

}
