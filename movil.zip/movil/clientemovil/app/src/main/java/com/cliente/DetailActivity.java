package com.cliente;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.cliente.R;
import com.cliente.constants.urlDeLaApi;
import com.cliente.fragments.DeleteFragment;
import com.cliente.interfaces.DeleteInterface;
import com.cliente.interfaces.UsuarioInterface;
import com.cliente.model.Usuario;

import java.net.URL;
import java.util.Optional;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DetailActivity extends AppCompatActivity implements DeleteInterface {

    TextView idText;
    TextView nameText;
    TextView priceText;
    Usuario user;

    UsuarioInterface interfaces;

    Button edit;
    Button delet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        idText = findViewById(R.id.txtId);
        nameText = findViewById(R.id.txtName);
        priceText = findViewById(R.id.txtDireccion);
        Long id = getIntent().getExtras().getLong("id");
        edit = findViewById(R.id.editarUser);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                callEdit();
            }
        });

        delet = findViewById(R.id.deleteUser);
        delet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDeleteDialog(user.getId());
            }
        });
        getOne(id);
    }
    private void getOne(Long id)
    {
        interfaces = usuarioInterface();
        Call<Usuario> call = interfaces.getOne(id);
        call.enqueue(new Callback<Usuario>() {
            @Override
            public void onResponse(Call<Usuario> call, Response<Usuario> response) {
                if(!response.isSuccessful())
                {
                    Toast toast = Toast.makeText(getApplication(), response.message(), Toast.LENGTH_LONG);
                    toast.show();
                    Log.e("err: ",response.message());
                    return;
                }
                user = response.body();
                idText.setText(String.valueOf(Math.toIntExact(user.getId())));
                nameText.setText(user.getNombre());
                priceText.setText(user.getDireccion());
            }

            @Override
            public void onFailure(Call<Usuario> call, Throwable t) {
                Toast toast = Toast.makeText(getApplication(), t.getMessage(), Toast.LENGTH_LONG);
                toast.show();
                Log.e("err: ", t.getMessage());
            }
        });
    }

    private void callEdit() {
        Intent intent = new Intent(getApplication(), EditActivity.class);
        intent.putExtra("user", user);
        startActivity(intent);
    }

    @Override
    public void showDeleteDialog(Long id) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        DeleteFragment deleteFragment = new DeleteFragment("Delete user", user.getId(), this);
        deleteFragment.show(fragmentManager, "Alert");
    }

    @Override
    public void delete(Long id) {
        interfaces = usuarioInterface();
        Call<Usuario> call = interfaces.delete(id);
        call.enqueue(new Callback<Usuario>() {
            @Override
            public void onResponse(Call<Usuario> call, Response<Usuario> response) {
                if(!response.isSuccessful())
                {
                    Toast toast = Toast.makeText(getApplication(), response.message(), Toast.LENGTH_LONG);
                    toast.show();
                    Log.e("err: ",response.message());
                    return;
                }
                Usuario user = response.body();
                Toast toast = Toast.makeText(getApplication(), user.getNombre().toString(), Toast.LENGTH_LONG);
                toast.show();
                callMain();
            }

            @Override
            public void onFailure(Call<Usuario> call, Throwable t) {
                Toast toast = Toast.makeText(getApplication(), t.getMessage(), Toast.LENGTH_LONG);
                toast.show();
                Log.e("err: ", t.getMessage());

            }

        });
    }

    private UsuarioInterface usuarioInterface()
    {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(urlDeLaApi.URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        interfaces = retrofit.create(UsuarioInterface.class);
        return interfaces;
    }

    private void callMain() {
        Intent intent = new Intent(getApplication(), MainActivity.class);
        startActivity(intent);
    }
}