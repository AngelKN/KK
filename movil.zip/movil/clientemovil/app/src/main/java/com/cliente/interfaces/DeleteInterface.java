package com.cliente.interfaces;

public interface DeleteInterface {

    void showDeleteDialog(Long id);
    void delete(Long id);
}
