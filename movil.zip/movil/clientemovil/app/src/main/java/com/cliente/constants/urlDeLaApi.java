package com.cliente.constants;

public class urlDeLaApi {

    public static final String URL = "http://192.168.100.59:8080/api/";

}
