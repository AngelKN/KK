package com.cliente.interfaces;

import com.cliente.model.Usuario;

import java.util.List;
import java.util.Optional;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface UsuarioInterface {

    @GET("all")
    Call<List<Usuario>> getAll();

    @GET("find/{id}")
    Call<Usuario> getOne(@Path("id") long id);

    @POST("save")
    Call<Usuario> save(@Body Usuario u);

    @DELETE("delete/{id}")
    Call<Usuario> delete(@Path("id") long id);

}
