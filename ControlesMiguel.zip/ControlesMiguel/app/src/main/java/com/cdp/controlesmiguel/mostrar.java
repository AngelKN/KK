package com.cdp.controlesmiguel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class mostrar extends AppCompatActivity {

    EditText txtNombre;
    TextView txtView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar);
        txtNombre = findViewById(R.id.txtNombre);
        txtView = findViewById(R.id.txtView);

        String datos= "Email: "+ getIntent().getStringExtra("txtEmail")+
                "Direccion: "+ getIntent().getStringExtra("txtDireccion")+
                "Departamento: "+ getIntent().getStringExtra("cbxDeptos")+
                "Tiempo: "+ getIntent().getStringExtra("tiempo");

        txtNombre.setText(getIntent().getStringExtra("txtNombre"));
        txtView.setText(datos);
    }
}